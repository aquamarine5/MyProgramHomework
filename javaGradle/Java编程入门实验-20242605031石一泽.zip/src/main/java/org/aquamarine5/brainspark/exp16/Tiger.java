package org.aquamarine5.brainspark.exp16;

public class Tiger extends Animal{
    @Override
    public String sound() {
        return "Tiger: RROOAARR";
    }
}
