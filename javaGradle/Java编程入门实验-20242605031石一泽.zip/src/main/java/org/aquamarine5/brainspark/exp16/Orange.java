package org.aquamarine5.brainspark.exp16;

public class Orange extends Fruit{
    @Override
    public String howToEat() {
        return "Orange: Make orange juice";
    }
}
