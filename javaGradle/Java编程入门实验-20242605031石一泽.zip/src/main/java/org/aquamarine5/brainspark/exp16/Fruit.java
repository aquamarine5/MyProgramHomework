package org.aquamarine5.brainspark.exp16;

public abstract class Fruit implements Edible {
}
