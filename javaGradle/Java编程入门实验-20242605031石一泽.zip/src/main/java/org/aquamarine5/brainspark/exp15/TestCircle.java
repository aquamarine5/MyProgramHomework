package org.aquamarine5.brainspark.exp15;

public class TestCircle {
    public static void main(String[] args){
        try{
            Circle c1 = new Circle(5);
            c1.setRadius(-5);
            Circle c2 = new Circle(0);
        } catch (InvalidRadiusException e) {
            System.out.println(e.getMessage());
        }
        System.out.println(Circle.getNumberOfObjects());
    }
}
