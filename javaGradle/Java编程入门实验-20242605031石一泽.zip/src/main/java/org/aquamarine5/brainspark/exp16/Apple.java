package org.aquamarine5.brainspark.exp16;

public class Apple extends Fruit{
    @Override
    public String howToEat() {
        return "Apple: Make apple cider";
    }
}
