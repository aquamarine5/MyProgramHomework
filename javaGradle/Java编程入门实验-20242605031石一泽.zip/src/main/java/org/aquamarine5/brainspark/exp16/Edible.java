package org.aquamarine5.brainspark.exp16;

public interface Edible {
    public abstract String howToEat();
}
